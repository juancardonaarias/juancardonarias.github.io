<?php

error_reporting(E_ALL);

class Usuario
{
    public $IdUsuario = null;
    public $nombre = null;
    public $telefono = null;
    public $email = null;
    public $tipo_usuario = null;
    public $contraseña = null;
}
?>
